﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prova
{
    class caso
    {
        
        public void InsertionSort()

        {
            int[] vett = new int[10000];
            Random r = new Random();

            for (int i = 0; i < vett.Length; i++)
            {
                vett[i] = r.Next(0, 99999);
            }

            
            int j;
            int indice;
            var watch = System.Diagnostics.Stopwatch.StartNew();

            for (int i = 1; i <  vett.Length;i++)
            {
                indice = vett[i];
                j = i;

                while ((j > 0) && (vett[j - 1] > indice))
                {
                    vett[j] = vett[j - 1];
                    j = j - 1;
                }
                vett[j] = indice;
                Console.WriteLine(vett[j]);
            }

            watch.Stop();
            var elapsedMs = watch.ElapsedMilliseconds;
            Console.WriteLine();
            Console.WriteLine(elapsedMs);
        }
    }
}
