﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prova
{
    class Program
    {
        static void Main(string[] args)
        {
            caso c = new caso();
            c.InsertionSort();
            Console.ReadLine();
        }
    }
}
