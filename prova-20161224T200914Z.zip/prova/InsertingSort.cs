﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prova
{
    class InsertingSort
    {
        public int[] Sort(int[] vett)
        {
            return vett;
        }
    }
}
